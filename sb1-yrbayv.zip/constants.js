export const API_URLS = {
  realmInfo: 'https://ep.wizz.cash/proxy/blockchain.atomicals.get_realm_info',
  resolvePayName: 'https://ep.wizz.cash/proxy/blockchain.atomicals.resolve_payname',
  bitcoinStats: 'https://api.coindesk.com/v1/bpi/currentprice/BTC.json',
};